﻿using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Newtonsoft.Json;
using Microsoft.Azure.Cosmos;
using System.Configuration;
using Microsoft.Azure.Cosmos.Scripts;
using System.Net;
using System.Net.Http;
using System.Text.Json.Nodes;
using System.Text.Json;
using System.IO;

using Azure;
using Azure.AI.DocumentIntelligence;
using Azure.AI.OpenAI;
using Azure.AI.OpenAI.Chat;
using System.ClientModel;
using OpenAI.Chat;
using LACE;
using Microsoft.Azure.Cosmos.Linq;
using System.Net.Http.Headers;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Microsoft.AspNetCore.Http;
using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;
using System.Text.RegularExpressions;
using System.Formats.Tar;

namespace LACE
{
    public class DocInfoExtraction
    {
        private readonly ILogger<fnDocExtraction> _logger;
        public DocInfoExtraction(ILogger<fnDocExtraction> logger)
        {
            _logger = logger;
        }
        static string openAIEndpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT");
        static string openAIApiKey = Environment.GetEnvironmentVariable("AZURE_OPENAI_API_KEY");
        static string openAIModelDeployment = Environment.GetEnvironmentVariable("AZURE_OPENAI_MODEL_DEPLOYMENT_NAME");
        static string documentIntelligenceEndpoint = Environment.GetEnvironmentVariable("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT");
        static string documentIntelligenceApiKey = Environment.GetEnvironmentVariable("AZURE_DOCUMENT_INTELLIGENCE_KEY");
        static string cosmosConnectionString = Environment.GetEnvironmentVariable("cosmosConnectionString");
        static string cosmosDatabaseName = Environment.GetEnvironmentVariable("cosmosDatabaseName");
        static string cosmosContainerName = Environment.GetEnvironmentVariable("cosmosContainerName");
        static string MLEndpoint = Environment.GetEnvironmentVariable("MLEndpoint");
        static string MLApiKey = Environment.GetEnvironmentVariable("MLKey");
        static string storageConnectionString = Environment.GetEnvironmentVariable("storageConnectionString");
        static string storageContainerName = Environment.GetEnvironmentVariable("storageContainerName");
        static string templateContainerName = Environment.GetEnvironmentVariable("templateContainerName");
        static string templateFileName = Environment.GetEnvironmentVariable("templateFileName");
        static string  templateJson = "";

        private  async Task<bool> init() {
            //check if all the required information is set
            if (string.IsNullOrEmpty(storageConnectionString) || string.IsNullOrEmpty(storageContainerName))
            {
                logInfo("Storage info is not set.");
                return false;
            }

            if (string.IsNullOrEmpty(documentIntelligenceEndpoint) || string.IsNullOrEmpty(documentIntelligenceApiKey))
            {
                logInfo("Document Intelligence info is not set.");
                return false;
            }

            if (string.IsNullOrEmpty(openAIEndpoint) || string.IsNullOrEmpty(openAIApiKey) || string.IsNullOrEmpty(openAIModelDeployment))
            {
                logInfo("Open AI info is not set.");
                return false;
            }

            if (string.IsNullOrEmpty(cosmosDatabaseName) || string.IsNullOrEmpty(cosmosContainerName) || string.IsNullOrEmpty(cosmosConnectionString))
            {
                logInfo("Cosmos DB information is not set.");
                return false;
            }

            if (string.IsNullOrEmpty(MLEndpoint) || string.IsNullOrEmpty(MLApiKey))
            {
                logInfo("ML info is not set.");
                return false;
            }

            templateJson = await BlobHelper.ReadBlobStringAsync(storageConnectionString, templateContainerName, templateFileName);

            if (string.IsNullOrEmpty(templateJson))
            {
                logInfo("Template is empty.");
                return false;
            }
            return true;
        }

        public  async Task ProcessDoc(string blobFile, byte[] blobBytes)
        {
            logInfo($"start processing: {blobFile}");

            if (! await init())
            {
                logInfo("Initialization failed.");
                return;
            }

            //1. get the markdown content from the document intelligence service
            var markdownContent = await GetMarkdownFromDocument(documentIntelligenceEndpoint, documentIntelligenceApiKey,
                blobBytes);
            if (string.IsNullOrEmpty(markdownContent))
            {
                logInfo($"Markdown content is empty for {blobFile}");
                return;
            }

            //2. get the json data from the openAI service
            var loanJson = await GetJsonData(openAIEndpoint, openAIApiKey, openAIModelDeployment,
                markdownContent, templateJson);
            if (string.IsNullOrEmpty(loanJson))
            {
                logInfo($"Loan Json content is empty for {blobFile}");
                return;
            }

            LoanInfo? loanObj = JsonConvert.DeserializeObject<LoanInfo>(loanJson);
            if (loanObj == null)
            {
                logInfo("Loan information is not valid.");
                return;
            }

            //3. score the loan
            var rating = await ScoreML(MLEndpoint, MLApiKey, loanObj);
            logInfo($"Loan is rated with {rating}");
            loanObj.Rating = rating;

            //it is expected the file name will be something like: "6657906f-e205-4168-b46e-ac99111b00f0/nov183.pdf"
            //only take the guid in the file name as id
            string sanitizedBlobFile = blobFile.IndexOf("/") >= 0 ? blobFile.Substring(0, blobFile.IndexOf("/")) : blobFile;
            //loanObj.id = blobFile.IndexOf("/") >= 0 ? blobFile.Substring(blobFile.IndexOf("/") + 1) : blobFile; 
            // Replace non-alphanumeric characters in blobFile
            //string sanitizedBlobFile = Regex.Replace(blobFile, "[^a-zA-Z0-9]", "-");
            sanitizedBlobFile = Regex.Replace(sanitizedBlobFile, "[^a-zA-Z0-9]", "-");
            //take first 50 characters of the sanitizedBlobFile as id
            loanObj.id = sanitizedBlobFile.Length > 50?sanitizedBlobFile.Substring(50):sanitizedBlobFile;

            //4. insert the loan info to cosmos
            await InsertLoanInfoToCosmos(cosmosConnectionString, cosmosDatabaseName, cosmosContainerName,
                loanObj);

            logInfo($"done processing: {blobFile}\r\n");

        }

        async Task<string> GetMarkdownFromDocument(string documentIntelligenceEndpoint, string documentIntelligenceApiKey,
    byte[] docData)
        {
            if (string.IsNullOrEmpty(documentIntelligenceEndpoint) ||
                string.IsNullOrEmpty(documentIntelligenceApiKey))
            {
                logInfo("connectionString is not set.");
                return string.Empty;
            }
            if (docData == null || docData.Length == 0)
            {
                logInfo("Blob content is empty.");
                return string.Empty;
            }

            var documentIntelligenceClient = new DocumentIntelligenceClient(new Uri(documentIntelligenceEndpoint), new AzureKeyCredential(documentIntelligenceApiKey));
            var markdownAnalysisContent = new AnalyzeDocumentContent()
            {
                Base64Source = BinaryData.FromBytes(docData)
            };

            Operation<AnalyzeResult> markdownAnalysisOperation = await documentIntelligenceClient.AnalyzeDocumentAsync(WaitUntil.Completed, "prebuilt-layout", markdownAnalysisContent, outputContentFormat: ContentFormat.Markdown);
            var markdown = markdownAnalysisOperation.Value.Content;
            logInfo(markdown);
            return markdown;
        }
        async Task<string> GetJsonData(string openAIEndpoint, string openAIApiKey, string openAIModelDeployment,
            string markDownContent, string template)
        {
            if (string.IsNullOrEmpty(markDownContent) || string.IsNullOrEmpty(template))
            {
                logInfo("template or markdown content is not set.");
                return string.Empty;
            }

            if (string.IsNullOrEmpty(openAIEndpoint) ||
                string.IsNullOrEmpty(openAIApiKey) ||
                string.IsNullOrEmpty(openAIModelDeployment))
            {
                logInfo("Open AI connection info is not set.");
                return string.Empty;
            }

            var openAIClient = new AzureOpenAIClient(new Uri(openAIEndpoint), new ApiKeyCredential(openAIApiKey));
            var chatClient = openAIClient.GetChatClient(openAIModelDeployment);
            ChatCompletion completion = await chatClient.CompleteChatAsync(
                [
                    // System messages represent instructions or other guidance about how the assistant should behave
                    new SystemChatMessage("You are an AI assistant that extracts data from documents and returns them as structured JSON objects. Do not return as a code block."),
        // User messages represent user input, whether historical or the most recent input
        new UserChatMessage($"Extract the data from this invoice. If a value is not present, provide null. Use the following structure: {template}"),
        new UserChatMessage(markDownContent),
    ]);

            var response = completion.Content[0].Text;
            logInfo(response);
            return response;
        }
        async Task<bool> ScoreML(string MLEndpoint, string apiKey, LoanInfo loanObj)
        {
            if (loanObj == null)
            {
                logInfo("Loan info is not set.");
                return false;
            }

            if (string.IsNullOrEmpty(MLEndpoint) || string.IsNullOrEmpty(apiKey))
            {
                logInfo("ML info is not set.");
                return false;
            }


            //List<int> data0 = new List<int> { 0,1,0,1,0,100000,0,10000,330,1, 2 }; //true
            //List<int> data0 = new List<int> { 2, 0, 0, 1, 0, 1500, 1800, 103, 333, 0, 2 }; //false


            List<int> data0 = new List<int>(loanObj.GetMLInput());
            List<List<int>> data = new List<List<int>> { data0 };
            var predictionRequest = new PredictionRequest() { input_data = new InputData(data) };
            string requestBody = JsonConvert.SerializeObject(predictionRequest);

            var handler = new HttpClientHandler()
            {
                ClientCertificateOptions = ClientCertificateOption.Manual,
                ServerCertificateCustomValidationCallback =
                                (httpRequestMessage, cert, cetChain, policyErrors) => { return true; }
            };
            using (var client = new HttpClient(handler))
            {
                // Request data goes here
                // More information can be found here:
                // https://docs.microsoft.com/azure/machine-learning/how-to-deploy-advanced-entry-script

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
                client.BaseAddress = new Uri(MLEndpoint);

                var content = new StringContent(requestBody);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                HttpResponseMessage response = await client.PostAsync("", content);

                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    var ratingResult = JsonConvert.DeserializeObject<List<bool>>(result);
                    if (ratingResult != null && ratingResult.Count > 0)
                    {
                        return ratingResult[0];
                    }
                    return false;
                }
                else
                {
                    logInfo(string.Format("The request failed with status code: {0}", response.StatusCode));

                    // Print the headers - they include the requert ID and the timestamp,
                    // which are useful for debugging the failure
                    logInfo(response.Headers.ToString());

                    string responseContent = await response.Content.ReadAsStringAsync();
                    logInfo(responseContent);
                }
            }
            return false;
        }

        async Task<bool> InsertLoanInfoToCosmos(string connectionString, string databaseName, string containerName,
            LoanInfo loanObj)
        {
            if (loanObj == null)
            {
                logInfo("Loan info is not set.");
                return false;
            }

            if (string.IsNullOrEmpty(databaseName) || string.IsNullOrEmpty(containerName) || string.IsNullOrEmpty(connectionString))
            {
                logInfo("Cosmos DB information is not set.");
                return false;
            }

            // New instance of CosmosClient class using a connection string
            using CosmosClient client = new(
                connectionString: connectionString
            );
            var container = client.GetContainer(databaseName, containerName);
            LoanInfo createdItem = await container.UpsertItemAsync<LoanInfo>(
            item: loanObj,
                partitionKey: new PartitionKey(loanObj.id)
            );
            return true;
        }

        void logInfo(string message)
        {
            _logger.LogInformation(message);
        }
    }
}
