using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;

namespace LACE
{
    public class fnDocExtraction
    {
        private readonly ILogger<fnDocExtraction> _logger;

        public fnDocExtraction(ILogger<fnDocExtraction> logger)
        {
            _logger = logger;
        }

        [Function(nameof(fnDocExtraction))]
        //[StorageAccount("storageConnectionString")]
        //public async Task Run([BlobTrigger("loanapplications/{name}", Connection = "FileDropSA")] Stream stream, string name)
        public async Task Run([BlobTrigger("loanapplications/{name}", Source = BlobTriggerSource.EventGrid, Connection = "storageConnectionString")] Stream stream, string name)
        {
            _logger.LogInformation($"C# Blob trigger function Processed blob\n Name: {name}");
            using var memoryStream = new MemoryStream();
            await stream.CopyToAsync(memoryStream);
            byte[] data = memoryStream.ToArray();
            _logger.LogInformation($"File content length: {name} \n length: {data.Length}");

            var docProcesser = new DocInfoExtraction(_logger);
            await docProcesser.ProcessDoc(name, data);
            //using var blobStreamReader = new StreamReader(stream);
            //var content = await blobStreamReader.ReadToEndAsync();
            //_logger.LogInformation($"C# Blob trigger function Processed blob\n Name: {name} \n Data: {content}");
        }
    }
}
