﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace LACE
{
    public class BlobHelper
    {
        public async static Task<string[]> GetBlobFiles(string connectionString, string containerName, string folderPath = "")
        {
            var blobFiles = new List<string>();
            var containerClient = new BlobContainerClient(connectionString, containerName);
            await foreach (var blobItem in containerClient.GetBlobsAsync(prefix: folderPath, traits: BlobTraits.None, states: BlobStates.None))
            {
                blobFiles.Add(blobItem.Name);
            }
            //await GetBlobFilesRecursive(containerClient, folderPath, blobFiles);
            return blobFiles.ToArray();
        }


        public static async Task<string> ReadBlobStringAsync(string connectionString, string containerName, string blobName)
        {
            byte[] content = await ReadBlobBytesAsync(connectionString, containerName, blobName);
            if (content != null && content.Length > 0)
            {
                return Encoding.UTF8.GetString(content);
            }
            return string.Empty;
        }
        public static async Task<byte[]> ReadBlobBytesAsync(string connectionString, string containerName, string blobName)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(containerName);
            BlobClient blobClient = containerClient.GetBlobClient(blobName);

            using (MemoryStream ms = new MemoryStream())
            {
                await blobClient.DownloadToAsync(ms);
                return ms.ToArray();
            }
        }

    }
}
