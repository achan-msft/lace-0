﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LACE
{
    public class LoanInfo
    {
        public string id { get; set; } 

        [JsonProperty("First Name")]
        public string FirstName { get; set; }

        [JsonProperty("Last Name")]
        public string LastName { get; set; }
        public string Gender { get; set; }

        [JsonProperty("Marital status")]
        public string Maritalstatus { get; set; }
        public string Dependents { get; set; }
        public string Education { get; set; }

        [JsonProperty("Self Employed /Job")]
        public string SelfEmployed { get; set; }
        [JsonProperty("Applicant Income (Yearly)")]
        public string AnnualIncome { get; set; }

        [JsonProperty("Loan Amount")]
        public string LoanAmount { get; set; }

        [JsonProperty("Credit History")]
        public string CreditHistory { get; set; }

        public bool? Rating { get; set; }
        //public string id
        //{
        //    get { return $"{FirstName}{LastName}{Gender}{LoanAmount}"; }
        //}

        public int[] GetMLInput()
        {
            return [
                parseGender(Gender),
                parseMaritalStatus(Maritalstatus),
                parseString(Dependents),
                parseEducation(Education),
                parseEmployment(SelfEmployed),
                parseString(AnnualIncome),0,
                parseString(LoanAmount),333,
                parseCreditHistory(CreditHistory),2];
        }

        int parseGender(string input)
        {
            return input.StartsWith("M", StringComparison.CurrentCultureIgnoreCase) ? 1 : 0;
        }
        int parseMaritalStatus(string input)
        {
            return input.Equals("Married", StringComparison.CurrentCultureIgnoreCase) ? 2
                : input.Equals("divorced", StringComparison.CurrentCultureIgnoreCase) ? 1
                : 0;
        }
        int parseEducation(string input)
        {
            return input.Equals("Graduate", StringComparison.CurrentCultureIgnoreCase) ? 1 : 0;
        }
        int parseEmployment(string input)
        {
            return input.Equals("Job", StringComparison.CurrentCultureIgnoreCase) ? 1 : 0;
        }
        int parseCreditHistory(string input)
        {
            if (int.TryParse(input, out int rtn))
            {
                return (rtn > 600 ? 1 : 0);
            }
            return 0;
        }
        int parseString(string? input)
        {

            if (string.IsNullOrEmpty(input))
            {
                return 0;
            }
            if (int.TryParse(input, out int rtn))
            {
                return rtn;
            }
            return 0;
        }
    }


    public class InputData
    {
        public List<string> columns = new List<string> {
            "Gender","Married","Dependents","Graduate",
      "Self_Employed","ApplicantIncome","CoapplicantIncome",
      "LoanAmount","Loan_Amount_Term","Credit_History","Property_Area"
        };
        public List<int> index = new List<int> { 1 };
        public List<List<int>> data { get; set; }
        public InputData() { }
        public InputData(List<List<int>> data)
        {
            this.data = data;
        }
    }

    public class PredictionRequest
    {
        public InputData input_data { get; set; }
    }
}
